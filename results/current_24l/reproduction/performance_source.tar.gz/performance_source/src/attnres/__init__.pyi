from collections.abc import Sequence

import torch
from torch import Tensor

from .modules import LearnedQuery

__version__: str


def attnres(
    values: Tensor | Sequence[Tensor],
    query: Tensor,
    *,
    eps: float = ...,
    scale: float = ...,
) -> Tensor: ...


def reference_attnres(
    values: Tensor,
    query: Tensor,
    *,
    eps: float = ...,
    scale: float = ...,
    compute_dtype: torch.dtype = ...,
) -> Tensor: ...


__all__: list[str]
